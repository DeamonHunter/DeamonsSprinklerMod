Sprinklers can be bought with the Shipping Catalogue and Shipping station. Do note that they do not run while you are away from them.

Installation instructions

Move DeamonsSprinklerMod.dll and DeamonsSprinkerMod.mod to staxels /bin/ folder. (This step may be improved later)
Double click on Sprinkler.mod and let it install.
Start the game and enjoy.

If you can't place the sprinklers then you need to run Staxel.ContentBuilder.exe in the /bin/ folder.
